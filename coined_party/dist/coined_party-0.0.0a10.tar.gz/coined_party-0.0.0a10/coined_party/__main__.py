from .coined_party import runGame

if __name__ == "__main__":
    runGame()